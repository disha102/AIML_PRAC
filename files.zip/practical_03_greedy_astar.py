# Practical 3: Informed Search - Greedy Best-First Search and A* Search
import heapq

graph = {
    'S': [('A', 3), ('B', 2)],
    'A': [('C', 4), ('D', 1)],
    'B': [('E', 3), ('F', 1)],
    'E': [('H', 5)],
    'F': [('I', 2), ('G', 3)],
    'C': [],
    'D': [],
    'H': [],
    'I': [],
    'G': []
}

heuristic = {
    'S': 13, 'A': 12, 'B': 4, 'C': 7, 'D': 3,
    'E': 8, 'F': 2, 'H': 4, 'I': 9, 'G': 0
}


def build_path(parent, goal):
    path = []
    node = goal
    while node is not None:
        path.append(node)
        node = parent[node]
    path.reverse()
    return path


def greedy_search(graph, heuristic, start, goal):
    # Priority = heuristic only: f(n) = h(n)
    queue = [(heuristic[start], start)]
    parent = {start: None}
    visited = set()

    while queue:
        _, node = heapq.heappop(queue)
        if node in visited:
            continue
        visited.add(node)
        print("Greedy expanded:", node, "h =", heuristic[node])

        if node == goal:
            return build_path(parent, goal)

        for neighbour, _cost in graph[node]:
            if neighbour not in visited:
                parent[neighbour] = node
                heapq.heappush(queue, (heuristic[neighbour], neighbour))

    return None


def a_star(graph, heuristic, start, goal):
    # Priority = g + h: f(n) = g(n) + h(n)
    queue = [(heuristic[start], start)]
    g = {start: 0}
    parent = {start: None}
    visited = set()

    while queue:
        f, node = heapq.heappop(queue)
        if node in visited:
            continue
        visited.add(node)
        print("A* expanded:", node, "g =", g[node],
              "h =", heuristic[node], "f =", g[node] + heuristic[node])

        if node == goal:
            return build_path(parent, goal), g[goal]

        for neighbour, cost in graph[node]:
            new_g = g[node] + cost
            if neighbour not in g or new_g < g[neighbour]:
                g[neighbour] = new_g
                parent[neighbour] = node
                heapq.heappush(queue, (new_g + heuristic[neighbour], neighbour))

    return None, None


def main():
    print("--- Greedy Best-First Search ---")
    greedy_path = greedy_search(graph, heuristic, 'S', 'G')
    print("Greedy path:", greedy_path)

    print("\n--- A* Search ---")
    astar_path, astar_cost = a_star(graph, heuristic, 'S', 'G')
    print("A* path:", astar_path)
    print("A* cost:", astar_cost)


if __name__ == "__main__":
    main()
