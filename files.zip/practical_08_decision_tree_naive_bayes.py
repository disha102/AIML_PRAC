# Practical 8: Decision Tree and Naive Bayes Classifiers
# Dataset: Iris
import pandas as pd
import matplotlib.pyplot as plt
from sklearn.datasets import load_iris
from sklearn.model_selection import train_test_split
from sklearn.tree import DecisionTreeClassifier, plot_tree
from sklearn.naive_bayes import GaussianNB
from sklearn.metrics import (accuracy_score, precision_score, recall_score,
                             f1_score, confusion_matrix,
                             classification_report, ConfusionMatrixDisplay)


def evaluate(name, y_true, y_pred, target_names):
    print("\n" + "=" * 45)
    print(name)
    print("=" * 45)
    print("Accuracy :", round(accuracy_score(y_true, y_pred), 4))
    print("Precision:", round(precision_score(y_true, y_pred, average="weighted"), 4))
    print("Recall   :", round(recall_score(y_true, y_pred, average="weighted"), 4))
    print("F1-Score :", round(f1_score(y_true, y_pred, average="weighted"), 4))
    print("\nClassification report:")
    print(classification_report(y_true, y_pred, target_names=target_names))
    print("Confusion matrix:")
    print(confusion_matrix(y_true, y_pred))


def main():
    iris = load_iris()
    X = pd.DataFrame(iris.data, columns=iris.feature_names)
    y = pd.Series(iris.target, name="target")

    print("First five records:")
    print(X.head())
    print("\nShape:", X.shape)
    print("Missing values:", X.isnull().sum().sum())

    X_train, X_test, y_train, y_test = train_test_split(
        X, y, test_size=0.20, random_state=42, stratify=y)
    print("\nTraining shape:", X_train.shape)
    print("Testing shape:", X_test.shape)

    # Decision Tree (max_depth limits overfitting)
    dt_model = DecisionTreeClassifier(criterion="gini", max_depth=3, random_state=42)
    dt_model.fit(X_train, y_train)
    pred_dt = dt_model.predict(X_test)

    # Gaussian Naive Bayes (for continuous features)
    nb_model = GaussianNB()
    nb_model.fit(X_train, y_train)
    pred_nb = nb_model.predict(X_test)

    evaluate("Decision Tree", y_test, pred_dt, iris.target_names)
    evaluate("Naive Bayes (Gaussian)", y_test, pred_nb, iris.target_names)

    comparison = pd.DataFrame({
        "Model": ["Decision Tree", "Naive Bayes"],
        "Accuracy": [accuracy_score(y_test, pred_dt), accuracy_score(y_test, pred_nb)],
        "Precision": [precision_score(y_test, pred_dt, average="weighted"),
                      precision_score(y_test, pred_nb, average="weighted")],
        "Recall": [recall_score(y_test, pred_dt, average="weighted"),
                   recall_score(y_test, pred_nb, average="weighted")],
        "F1-Score": [f1_score(y_test, pred_dt, average="weighted"),
                     f1_score(y_test, pred_nb, average="weighted")],
    })
    print("\nModel comparison")
    print(comparison.round(4).to_string(index=False))

    ConfusionMatrixDisplay.from_predictions(y_test, pred_dt,
                                            display_labels=iris.target_names)
    plt.title("Confusion Matrix - Decision Tree")
    plt.show()

    ConfusionMatrixDisplay.from_predictions(y_test, pred_nb,
                                            display_labels=iris.target_names)
    plt.title("Confusion Matrix - Naive Bayes")
    plt.show()

    plt.figure(figsize=(15, 8))
    plot_tree(dt_model, feature_names=iris.feature_names,
              class_names=iris.target_names, filled=True)
    plt.title("Decision Tree for Iris Dataset")
    plt.show()


if __name__ == "__main__":
    main()
