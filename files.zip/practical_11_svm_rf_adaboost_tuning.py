# Practical 11: SVM, Random Forest and AdaBoost with Cross-Validation and GridSearchCV
# Dataset: Wine
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns
from sklearn.datasets import load_wine
from sklearn.model_selection import (train_test_split, StratifiedKFold,
                                     cross_val_score, GridSearchCV)
from sklearn.pipeline import Pipeline
from sklearn.preprocessing import StandardScaler
from sklearn.svm import SVC
from sklearn.ensemble import RandomForestClassifier, AdaBoostClassifier
from sklearn.metrics import (accuracy_score, precision_score, recall_score,
                             f1_score, classification_report, confusion_matrix)


def scores_row(name, stage, y_true, y_pred):
    return {
        "Model": name,
        "Stage": stage,
        "Accuracy": accuracy_score(y_true, y_pred),
        "Precision": precision_score(y_true, y_pred, average="weighted"),
        "Recall": recall_score(y_true, y_pred, average="weighted"),
        "F1-Score": f1_score(y_true, y_pred, average="weighted"),
    }


def main():
    wine = load_wine()
    X = pd.DataFrame(wine.data, columns=wine.feature_names)
    y = wine.target

    print("Shape:", X.shape)
    print("Classes:", np.unique(y))
    print("Missing values:", X.isnull().sum().sum())

    sns.countplot(x=y)
    plt.title("Wine Class Distribution")
    plt.show()

    X_train, X_test, y_train, y_test = train_test_split(
        X, y, test_size=0.20, random_state=42, stratify=y)
    print("Training samples:", len(X_train), "| Testing samples:", len(X_test))

    models = {
        "SVM": Pipeline([("scaler", StandardScaler()), ("clf", SVC())]),
        "Random Forest": Pipeline([("clf", RandomForestClassifier(random_state=42))]),
        "AdaBoost": Pipeline([("clf", AdaBoostClassifier(random_state=42))]),
    }

    # Before tuning
    results = []
    for name, model in models.items():
        model.fit(X_train, y_train)
        results.append(scores_row(name, "Before", y_test, model.predict(X_test)))

    # 5-fold cross-validation
    cv = StratifiedKFold(n_splits=5, shuffle=True, random_state=42)
    print("\n5-Fold Cross-Validation (accuracy)")
    for name, model in models.items():
        scores = cross_val_score(model, X_train, y_train, cv=cv, scoring="accuracy")
        print(name, "fold scores:", scores.round(4), "mean:", round(scores.mean(), 4))

    # Hyperparameter grids
    param_grids = {
        "SVM": {
            "clf__C": [0.1, 1, 10, 100],
            "clf__kernel": ["linear", "rbf"],
            "clf__gamma": ["scale", "auto"],
        },
        "Random Forest": {
            "clf__n_estimators": [50, 100, 200],
            "clf__max_depth": [None, 5, 10],
            "clf__min_samples_split": [2, 5],
        },
        "AdaBoost": {
            "clf__n_estimators": [50, 100, 200],
            "clf__learning_rate": [0.01, 0.1, 1.0],
        },
    }

    optimized = {}
    for name, model in models.items():
        gs = GridSearchCV(model, param_grids[name], cv=cv,
                          scoring="accuracy", n_jobs=-1)
        gs.fit(X_train, y_train)
        optimized[name] = gs.best_estimator_
        print("\n" + name)
        print("Best parameters:", gs.best_params_)
        print("Best CV accuracy:", round(gs.best_score_, 4))

    # After tuning
    for name, model in optimized.items():
        pred = model.predict(X_test)
        results.append(scores_row(name, "After", y_test, pred))
        print("\nClassification report (tuned " + name + ")")
        print(classification_report(y_test, pred, target_names=wine.target_names))

    results_df = pd.DataFrame(results)
    print("\nComparison table")
    print(results_df.round(4).to_string(index=False))

    pivot = results_df.pivot(index="Model", columns="Stage", values="Accuracy")
    pivot.plot(kind="bar", figsize=(9, 5))
    plt.title("Accuracy Before and After Tuning")
    plt.ylabel("Test accuracy")
    plt.ylim(0, 1.05)
    plt.xticks(rotation=0)
    plt.show()

    best_name = max(optimized,
                    key=lambda n: accuracy_score(y_test, optimized[n].predict(X_test)))
    best_pred = optimized[best_name].predict(X_test)

    plt.figure(figsize=(6, 5))
    sns.heatmap(confusion_matrix(y_test, best_pred), annot=True, fmt="d",
                cmap="Blues", xticklabels=wine.target_names,
                yticklabels=wine.target_names)
    plt.title("Confusion Matrix - " + best_name)
    plt.xlabel("Predicted")
    plt.ylabel("Actual")
    plt.show()
    print("Best model on test set:", best_name)


if __name__ == "__main__":
    main()
