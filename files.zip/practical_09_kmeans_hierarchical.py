# Practical 9: Clustering - K-Means and Hierarchical Clustering
# Dataset: Iris (labels are used only for comparison, not for training)
import pandas as pd
import matplotlib.pyplot as plt
from sklearn.datasets import load_iris
from sklearn.preprocessing import StandardScaler
from sklearn.cluster import KMeans, AgglomerativeClustering
from sklearn.decomposition import PCA
from sklearn.metrics import silhouette_score
from scipy.cluster.hierarchy import linkage, dendrogram


def main():
    iris = load_iris()
    df = pd.DataFrame(iris.data, columns=iris.feature_names)

    print("First five records:")
    print(df.head())
    print("\nShape:", df.shape)
    print("Missing values:", df.isnull().sum().sum())

    X = StandardScaler().fit_transform(df)

    # Elbow method
    wcss = []
    for k in range(1, 11):
        km = KMeans(n_clusters=k, random_state=42, n_init=10)
        km.fit(X)
        wcss.append(km.inertia_)

    plt.figure(figsize=(8, 5))
    plt.plot(range(1, 11), wcss, marker="o")
    plt.title("Elbow Method")
    plt.xlabel("Number of clusters (K)")
    plt.ylabel("WCSS")
    plt.grid(True)
    plt.show()

    # K-Means with K = 3
    kmeans = KMeans(n_clusters=3, random_state=42, n_init=10)
    km_labels = kmeans.fit_predict(X)
    df["KMeans_Cluster"] = km_labels

    # PCA is used only to draw the 4 features on a 2D plot
    pca = PCA(n_components=2)
    X_pca = pca.fit_transform(X)

    plt.figure(figsize=(8, 5))
    plt.scatter(X_pca[:, 0], X_pca[:, 1], c=km_labels, cmap="viridis", s=50)
    plt.title("K-Means Clusters (PCA view)")
    plt.xlabel("PC1")
    plt.ylabel("PC2")
    plt.show()

    # Hierarchical clustering (Ward linkage)
    hc = AgglomerativeClustering(n_clusters=3, linkage="ward")
    hc_labels = hc.fit_predict(X)
    df["Hierarchical_Cluster"] = hc_labels

    Z = linkage(X, method="ward")
    plt.figure(figsize=(12, 6))
    dendrogram(Z, truncate_mode="lastp", p=30, show_leaf_counts=True)
    plt.title("Dendrogram")
    plt.xlabel("Data points / merged groups")
    plt.ylabel("Ward distance")
    plt.show()

    plt.figure(figsize=(8, 5))
    plt.scatter(X_pca[:, 0], X_pca[:, 1], c=hc_labels, cmap="plasma", s=50)
    plt.title("Hierarchical Clusters (PCA view)")
    plt.xlabel("PC1")
    plt.ylabel("PC2")
    plt.show()

    print("\nK-Means silhouette score:", round(silhouette_score(X, km_labels), 3))
    print("Hierarchical silhouette score:", round(silhouette_score(X, hc_labels), 3))

    print("\nK-Means cluster means:")
    print(df.groupby("KMeans_Cluster")[iris.feature_names].mean().round(2))
    print("\nHierarchical cluster means:")
    print(df.groupby("Hierarchical_Cluster")[iris.feature_names].mean().round(2))

    print("\nK-Means clusters vs actual species:")
    print(pd.crosstab(pd.Series(km_labels, name="KMeans cluster"),
                      pd.Series(iris.target_names[iris.target], name="Actual species")))


if __name__ == "__main__":
    main()
