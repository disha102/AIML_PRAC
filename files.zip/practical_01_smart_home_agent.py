# Practical 1: Simple Intelligent Agent (Smart Home Controller)


def smart_home_agent(temperature, light_intensity, person_present):
    # Fan turns ON when it is hotter than 28 C
    if temperature > 28:
        fan = "ON"
    else:
        fan = "OFF"

    # Light turns ON only if a person is present and it is dark enough
    if person_present and light_intensity < 40:
        light = "ON"
    else:
        light = "OFF"

    return fan, light


def main():
    print("SMART HOME AGENT")
    print("----------------")

    temperature = float(input("Enter room temperature (C): "))
    light_intensity = float(input("Enter light intensity (0-100): "))
    presence = input("Is a person present? (yes/no): ").strip().lower()

    if light_intensity < 0 or light_intensity > 100:
        print("Light intensity must be between 0 and 100")
        return

    person_present = (presence == "yes")
    fan, light = smart_home_agent(temperature, light_intensity, person_present)

    print("\nTemperature:", temperature, "C")
    print("Light intensity:", light_intensity, "%")
    print("Person present:", person_present)
    print("Fan:", fan)
    print("Light:", light)


if __name__ == "__main__":
    main()
