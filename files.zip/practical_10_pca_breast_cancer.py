# Practical 10: Dimensionality Reduction using PCA
# Dataset: Breast Cancer Wisconsin (Diagnostic), 30 features
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
from sklearn.datasets import load_breast_cancer
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import StandardScaler
from sklearn.decomposition import PCA
from sklearn.linear_model import LogisticRegression
from sklearn.metrics import (accuracy_score, precision_score, recall_score,
                             f1_score, classification_report,
                             ConfusionMatrixDisplay)


def main():
    data = load_breast_cancer()
    X = pd.DataFrame(data.data, columns=data.feature_names)
    y = data.target

    print("First five rows:")
    print(X.head())
    print("\nOriginal shape:", X.shape)
    print("Class distribution:")
    print(pd.Series(y).map({0: "Malignant", 1: "Benign"}).value_counts())

    X_train, X_test, y_train, y_test = train_test_split(
        X, y, test_size=0.20, random_state=42, stratify=y)

    # Standardize (fit on training data only)
    scaler = StandardScaler()
    X_train_s = scaler.fit_transform(X_train)
    X_test_s = scaler.transform(X_test)

    # PCA keeping 95% of the training variance
    pca95 = PCA(n_components=0.95)
    X_train_pca = pca95.fit_transform(X_train_s)
    X_test_pca = pca95.transform(X_test_s)

    print("\nFeatures before PCA:", X_train_s.shape[1])
    print("Components after PCA:", X_train_pca.shape[1])
    print("Variance kept:", round(pca95.explained_variance_ratio_.sum(), 4))

    # Explained variance graph
    pca_all = PCA().fit(X_train_s)
    cumulative = np.cumsum(pca_all.explained_variance_ratio_)
    n = len(cumulative)

    plt.figure(figsize=(9, 5))
    plt.bar(range(1, n + 1), pca_all.explained_variance_ratio_,
            alpha=0.6, label="Individual explained variance")
    plt.plot(range(1, n + 1), cumulative, marker="o", color="red",
             label="Cumulative explained variance")
    plt.axhline(0.95, linestyle="--", label="95% threshold")
    plt.xlabel("Number of principal components")
    plt.ylabel("Explained variance ratio")
    plt.title("PCA Explained Variance")
    plt.legend()
    plt.show()

    # 2D visualization
    pca2 = PCA(n_components=2)
    pca2.fit(X_train_s)
    X_all_2d = pca2.transform(scaler.transform(X))

    plt.figure(figsize=(9, 6))
    for value, name in [(0, "Malignant"), (1, "Benign")]:
        mask = y == value
        plt.scatter(X_all_2d[mask, 0], X_all_2d[mask, 1],
                    label=name, alpha=0.7, s=35)
    plt.xlabel("Principal Component 1")
    plt.ylabel("Principal Component 2")
    plt.title("Breast Cancer Data after PCA")
    plt.legend()
    plt.grid(True, alpha=0.3)
    plt.show()

    # Classification before and after PCA
    model_orig = LogisticRegression(max_iter=5000)
    model_orig.fit(X_train_s, y_train)
    pred_orig = model_orig.predict(X_test_s)

    model_pca = LogisticRegression(max_iter=5000)
    model_pca.fit(X_train_pca, y_train)
    pred_pca = model_pca.predict(X_test_pca)

    comparison = pd.DataFrame({
        "Model": ["Without PCA (30 features)",
                  f"With PCA ({X_train_pca.shape[1]} components)"],
        "Accuracy": [accuracy_score(y_test, pred_orig),
                     accuracy_score(y_test, pred_pca)],
        "Precision": [precision_score(y_test, pred_orig),
                      precision_score(y_test, pred_pca)],
        "Recall": [recall_score(y_test, pred_orig),
                   recall_score(y_test, pred_pca)],
        "F1 Score": [f1_score(y_test, pred_orig),
                     f1_score(y_test, pred_pca)],
    })
    print("\nClassification comparison")
    print(comparison.round(4).to_string(index=False))

    print("\nReport without PCA")
    print(classification_report(y_test, pred_orig, target_names=data.target_names))
    print("Report with PCA")
    print(classification_report(y_test, pred_pca, target_names=data.target_names))

    fig, axes = plt.subplots(1, 2, figsize=(11, 4))
    ConfusionMatrixDisplay.from_predictions(
        y_test, pred_orig, display_labels=data.target_names,
        cmap="Blues", ax=axes[0], colorbar=False)
    axes[0].set_title("Without PCA")
    ConfusionMatrixDisplay.from_predictions(
        y_test, pred_pca, display_labels=data.target_names,
        cmap="Greens", ax=axes[1], colorbar=False)
    axes[1].set_title("With PCA")
    plt.tight_layout()
    plt.show()


if __name__ == "__main__":
    main()
