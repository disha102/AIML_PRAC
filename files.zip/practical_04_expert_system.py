# Practical 4: Rule-Based Expert System using Propositional Logic
# Forward Chaining (data-driven) and Backward Chaining (goal-driven)

rules = [
    ({"fever", "cough"}, "respiratory_infection"),
    ({"respiratory_infection", "body_pain"}, "flu"),
    ({"fever", "rash"}, "measles"),
    ({"flu"}, "viral_infection"),
    ({"viral_infection"}, "rest_and_hydration"),
]


def forward_chaining(facts, rules):
    facts = set(facts)
    new_fact_added = True

    while new_fact_added:
        new_fact_added = False
        for conditions, conclusion in rules:
            if conditions.issubset(facts) and conclusion not in facts:
                facts.add(conclusion)
                print("Rule fired:", " AND ".join(sorted(conditions)), "->", conclusion)
                new_fact_added = True

    return facts


def backward_chaining(goal, facts, rules, visited=None):
    if visited is None:
        visited = set()

    if goal in facts:
        print("Fact found:", goal)
        return True

    if goal in visited:
        return False
    visited.add(goal)

    print("Checking goal:", goal)
    for conditions, conclusion in rules:
        if conclusion == goal:
            if all(backward_chaining(c, facts, rules, visited) for c in conditions):
                print("Goal proved:", goal)
                return True

    return False


def main():
    user_input = input("Enter facts separated by comma: ")
    facts = {f.strip() for f in user_input.split(",") if f.strip()}
    goal = input("Enter the goal to verify: ").strip()

    print("\n--- Forward Chaining ---")
    final_facts = forward_chaining(facts, rules)
    print("Final knowledge base:", sorted(final_facts))

    print("\n--- Backward Chaining ---")
    if backward_chaining(goal, facts, rules):
        print("Result: goal", goal, "CAN be proved")
    else:
        print("Result: goal", goal, "cannot be proved from the given facts")


if __name__ == "__main__":
    main()
