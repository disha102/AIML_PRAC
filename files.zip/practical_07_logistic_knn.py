# Practical 7: Data Preprocessing, Logistic Regression and KNN
# Dataset: Iris
import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns
from sklearn.datasets import load_iris
from sklearn.model_selection import train_test_split
from sklearn.pipeline import make_pipeline
from sklearn.preprocessing import StandardScaler
from sklearn.linear_model import LogisticRegression
from sklearn.neighbors import KNeighborsClassifier
from sklearn.metrics import (accuracy_score, precision_score, recall_score,
                             f1_score, confusion_matrix, classification_report)


def show_scores(name, y_true, y_pred, target_names):
    print("\n" + name)
    print("-" * 40)
    print("Accuracy :", round(accuracy_score(y_true, y_pred), 4))
    print("Precision:", round(precision_score(y_true, y_pred, average="weighted"), 4))
    print("Recall   :", round(recall_score(y_true, y_pred, average="weighted"), 4))
    print("F1-Score :", round(f1_score(y_true, y_pred, average="weighted"), 4))
    print(classification_report(y_true, y_pred, target_names=target_names))


def main():
    iris = load_iris()
    X = pd.DataFrame(iris.data, columns=iris.feature_names)
    y = iris.target

    print("First five records:")
    print(X.head())
    print("\nShape:", X.shape)
    print("Missing values:", X.isnull().sum().sum())

    species = pd.Series(y).map(dict(enumerate(iris.target_names)))
    sns.countplot(x=species)
    plt.title("Number of Samples per Species")
    plt.show()

    X_train, X_test, y_train, y_test = train_test_split(
        X, y, test_size=0.20, random_state=42, stratify=y)
    print("\nTraining samples:", len(X_train))
    print("Testing samples:", len(X_test))

    # scaling is inside the pipeline so it is fitted on training data only
    lr_model = make_pipeline(StandardScaler(), LogisticRegression(max_iter=1000))
    knn_model = make_pipeline(StandardScaler(), KNeighborsClassifier(n_neighbors=5))

    lr_model.fit(X_train, y_train)
    knn_model.fit(X_train, y_train)

    pred_lr = lr_model.predict(X_test)
    pred_knn = knn_model.predict(X_test)

    show_scores("Logistic Regression", y_test, pred_lr, iris.target_names)
    show_scores("KNN (k=5)", y_test, pred_knn, iris.target_names)

    fig, axes = plt.subplots(1, 2, figsize=(12, 5))
    models_to_plot = [
        ("Logistic Regression", pred_lr, "Blues"),
        ("KNN (k=5)", pred_knn, "Greens"),
    ]
    for ax, (name, pred, color) in zip(axes, models_to_plot):
        cm = confusion_matrix(y_test, pred)
        sns.heatmap(cm, annot=True, fmt="d", cmap=color,
                    xticklabels=iris.target_names,
                    yticklabels=iris.target_names, ax=ax)
        ax.set_title(name)
        ax.set_xlabel("Predicted species")
        ax.set_ylabel("Actual species")
    plt.tight_layout()
    plt.show()

    results = pd.DataFrame({
        "Model": ["Logistic Regression", "KNN (k=5)"],
        "Accuracy": [accuracy_score(y_test, pred_lr), accuracy_score(y_test, pred_knn)],
        "Precision": [precision_score(y_test, pred_lr, average="weighted"),
                      precision_score(y_test, pred_knn, average="weighted")],
        "Recall": [recall_score(y_test, pred_lr, average="weighted"),
                   recall_score(y_test, pred_knn, average="weighted")],
        "F1-Score": [f1_score(y_test, pred_lr, average="weighted"),
                     f1_score(y_test, pred_knn, average="weighted")],
    })
    print("\nComparison")
    print(results.round(4).to_string(index=False))

    results.set_index("Model").plot(kind="bar", figsize=(10, 5), ylim=(0.85, 1.0))
    plt.title("Logistic Regression vs KNN")
    plt.ylabel("Score")
    plt.xticks(rotation=0)
    plt.show()


if __name__ == "__main__":
    main()
