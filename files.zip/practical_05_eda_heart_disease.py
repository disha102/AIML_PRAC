# Practical 5: Data Preprocessing and Exploratory Data Analysis
# Dataset: UCI Heart Disease (Cleveland). Needs internet access.
import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns
from sklearn.model_selection import train_test_split
from sklearn.compose import ColumnTransformer
from sklearn.pipeline import Pipeline
from sklearn.impute import SimpleImputer
from sklearn.preprocessing import StandardScaler, OneHotEncoder

sns.set_theme(style="whitegrid")

URL = ("https://archive.ics.uci.edu/ml/machine-learning-databases/"
       "heart-disease/processed.cleveland.data")

COLUMNS = ["age", "sex", "cp", "trestbps", "chol", "fbs", "restecg",
           "thalach", "exang", "oldpeak", "slope", "ca", "thal", "num"]

NUMERIC_FEATURES = ["age", "trestbps", "chol", "thalach", "oldpeak"]
CATEGORICAL_FEATURES = ["sex", "cp", "fbs", "restecg", "exang", "slope", "ca", "thal"]


def load_data():
    df = pd.read_csv(URL, names=COLUMNS, na_values="?")
    df = df.apply(pd.to_numeric, errors="coerce")
    return df


def clean_data(df):
    print("Duplicate rows:", df.duplicated().sum())
    df = df.drop_duplicates().copy()

    # binary target: 0 = no heart disease, 1 = heart disease present
    df["target"] = (df["num"] > 0).astype(int)
    df = df.drop(columns=["num"])
    return df


def run_eda(df):
    print("\nDescriptive statistics:")
    print(df[NUMERIC_FEATURES].describe().round(2))

    print("\nMedian values:")
    print(df[NUMERIC_FEATURES].median())

    print("\nTarget counts:")
    print(df["target"].value_counts())

    df[NUMERIC_FEATURES].hist(bins=15, figsize=(12, 8), edgecolor="black")
    plt.suptitle("Histograms of Numerical Features")
    plt.tight_layout()
    plt.show()

    plt.figure(figsize=(12, 6))
    sns.boxplot(data=df[NUMERIC_FEATURES], orient="h")
    plt.title("Boxplots of Numerical Features")
    plt.tight_layout()
    plt.show()

    plt.figure(figsize=(6, 4))
    sns.countplot(x="target", data=df)
    plt.title("Heart Disease Target Distribution")
    plt.xlabel("Target (0 = no disease, 1 = disease)")
    plt.tight_layout()
    plt.show()


def preprocess(df):
    X = df.drop(columns=["target"])
    y = df["target"]

    # split BEFORE fitting imputers and scalers to avoid data leakage
    X_train, X_test, y_train, y_test = train_test_split(
        X, y, test_size=0.20, random_state=42, stratify=y)

    numeric_pipeline = Pipeline([
        ("imputer", SimpleImputer(strategy="median")),
        ("scaler", StandardScaler()),
    ])

    categorical_pipeline = Pipeline([
        ("imputer", SimpleImputer(strategy="most_frequent")),
        ("encoder", OneHotEncoder(handle_unknown="ignore")),
    ])

    preprocessor = ColumnTransformer([
        ("num", numeric_pipeline, NUMERIC_FEATURES),
        ("cat", categorical_pipeline, CATEGORICAL_FEATURES),
    ])

    X_train_processed = preprocessor.fit_transform(X_train)
    X_test_processed = preprocessor.transform(X_test)

    print("\nTraining records:", X_train_processed.shape[0])
    print("Testing records:", X_test_processed.shape[0])
    print("Features after preprocessing:", X_train_processed.shape[1])
    return X_train_processed, X_test_processed, y_train, y_test


def main():
    df = load_data()
    print("First five rows:")
    print(df.head())
    print("\nShape:", df.shape)
    print("\nMissing values per column:")
    print(df.isnull().sum())

    df = clean_data(df)
    run_eda(df)
    preprocess(df)


if __name__ == "__main__":
    main()
