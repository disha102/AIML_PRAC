# Practical 6: Linear Regression and Polynomial Regression
# Dataset: California Housing (downloaded by scikit-learn on first run)
import pandas as pd
import matplotlib.pyplot as plt
from sklearn.datasets import fetch_california_housing
from sklearn.model_selection import train_test_split
from sklearn.linear_model import LinearRegression
from sklearn.preprocessing import PolynomialFeatures, StandardScaler
from sklearn.pipeline import Pipeline
from sklearn.metrics import mean_squared_error, mean_absolute_error, r2_score


def main():
    housing = fetch_california_housing(as_frame=True)
    X = housing.data
    y = housing.target

    print("First five records:")
    print(X.head())
    print("\nShape:", X.shape)
    print("Missing values:", X.isnull().sum().sum())

    plt.figure(figsize=(8, 5))
    plt.scatter(X["MedInc"], y, alpha=0.25, s=10)
    plt.xlabel("Median Income")
    plt.ylabel("Median House Value ($100,000 units)")
    plt.title("Median Income vs House Value")
    plt.show()

    X_train, X_test, y_train, y_test = train_test_split(
        X, y, test_size=0.20, random_state=42)
    print("Training records:", len(X_train))
    print("Testing records:", len(X_test))

    # Linear Regression
    lin_model = LinearRegression()
    lin_model.fit(X_train, y_train)
    y_pred_lin = lin_model.predict(X_test)

    # Polynomial Regression (degree 2)
    poly_model = Pipeline([
        ("poly", PolynomialFeatures(degree=2, include_bias=False)),
        ("scaler", StandardScaler()),
        ("regression", LinearRegression()),
    ])
    poly_model.fit(X_train, y_train)
    y_pred_poly = poly_model.predict(X_test)

    results = pd.DataFrame({
        "Model": ["Linear Regression", "Polynomial Regression"],
        "MSE": [mean_squared_error(y_test, y_pred_lin),
                mean_squared_error(y_test, y_pred_poly)],
        "MAE": [mean_absolute_error(y_test, y_pred_lin),
                mean_absolute_error(y_test, y_pred_poly)],
        "R2 Score": [r2_score(y_test, y_pred_lin),
                     r2_score(y_test, y_pred_poly)],
    })
    print("\nModel comparison")
    print(results.round(4).to_string(index=False))

    # Actual vs predicted
    fig, axes = plt.subplots(1, 2, figsize=(12, 5))
    for ax, name, pred in zip(axes,
                              ["Linear Regression", "Polynomial Regression"],
                              [y_pred_lin, y_pred_poly]):
        ax.scatter(y_test, pred, alpha=0.25, s=10)
        low = min(y_test.min(), pred.min())
        high = max(y_test.max(), pred.max())
        ax.plot([low, high], [low, high], "r--")
        ax.set_title(name)
        ax.set_xlabel("Actual value")
        ax.set_ylabel("Predicted value")
    plt.tight_layout()
    plt.show()

    # Residual plot
    residual_lin = y_test.to_numpy() - y_pred_lin
    residual_poly = y_test.to_numpy() - y_pred_poly
    fig, axes = plt.subplots(1, 2, figsize=(12, 5))
    axes[0].scatter(y_pred_lin, residual_lin, alpha=0.25, s=10)
    axes[0].axhline(0, linestyle="--")
    axes[0].set_title("Linear Regression Residuals")
    axes[0].set_xlabel("Predicted value")
    axes[0].set_ylabel("Residual")
    axes[1].scatter(y_pred_poly, residual_poly, alpha=0.25, s=10)
    axes[1].axhline(0, linestyle="--")
    axes[1].set_title("Polynomial Regression Residuals")
    axes[1].set_xlabel("Predicted value")
    axes[1].set_ylabel("Residual")
    plt.tight_layout()
    plt.show()


if __name__ == "__main__":
    main()
