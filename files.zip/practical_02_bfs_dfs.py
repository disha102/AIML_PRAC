# Practical 2: Uninformed Search - Breadth First Search (BFS) and Depth First Search (DFS)
from collections import deque
import time

graph = {
    'A': ['B', 'C'],
    'B': ['D', 'E'],
    'C': ['F', 'G'],
    'D': ['H', 'I'],
    'E': ['J'],
    'F': [],
    'G': [],
    'H': [],
    'I': [],
    'J': []
}


def bfs(graph, start, goal):
    queue = deque([(start, [start])])
    visited = set()
    explored = []

    while queue:
        node, path = queue.popleft()
        if node in visited:
            continue
        visited.add(node)
        explored.append(node)

        if node == goal:
            return path, explored

        for neighbour in graph[node]:
            if neighbour not in visited:
                queue.append((neighbour, path + [neighbour]))

    return None, explored


def dfs(graph, start, goal):
    stack = [(start, [start])]
    visited = set()
    explored = []

    while stack:
        node, path = stack.pop()
        if node in visited:
            continue
        visited.add(node)
        explored.append(node)

        if node == goal:
            return path, explored

        # reversed so the left child is explored first
        for neighbour in reversed(graph[node]):
            if neighbour not in visited:
                stack.append((neighbour, path + [neighbour]))

    return None, explored


def main():
    start, goal = 'A', 'J'

    t1 = time.perf_counter()
    bfs_path, bfs_explored = bfs(graph, start, goal)
    bfs_time = time.perf_counter() - t1

    t2 = time.perf_counter()
    dfs_path, dfs_explored = dfs(graph, start, goal)
    dfs_time = time.perf_counter() - t2

    print("===== BFS RESULT =====")
    print("Traversal:", " -> ".join(bfs_explored))
    print("Path:", " -> ".join(bfs_path))
    print("Path length:", len(bfs_path) - 1)
    print("Nodes explored:", len(bfs_explored))
    print("Execution time:", bfs_time, "seconds")

    print("\n===== DFS RESULT =====")
    print("Traversal:", " -> ".join(dfs_explored))
    print("Path:", " -> ".join(dfs_path))
    print("Path length:", len(dfs_path) - 1)
    print("Nodes explored:", len(dfs_explored))
    print("Execution time:", dfs_time, "seconds")


if __name__ == "__main__":
    main()
